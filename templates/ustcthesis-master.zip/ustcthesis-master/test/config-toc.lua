testfiledir = "./test/testfiles-toc"
testsuppdir = testfiledir .. "/support"

checkruns = 2
